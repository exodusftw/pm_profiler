# Changelog


### 2015-07-19 Jeremy Grant 
* initial Creation of Class to manage SUSE power management profiles


